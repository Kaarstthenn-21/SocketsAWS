﻿namespace SharedKernel.Domain.Entities;
    
public class SocketConnection
{
    public string Id { get; set; } = null!;
    public string DomainName { get; set; } = null!;
    public string Stage { get; set; } = null!;
    public DateTime CreationDate { get; set; }
    public string CreatedBy { get; set; } = null!;
}

