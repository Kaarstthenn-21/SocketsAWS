﻿namespace SharedKernel.Domain.Entities.Common;
    
public class PersonAddress
{
    public int Id { get; set; }
    public int PersonId { get; set; }
    public string Address { get; set; } = null!;
    public string? Reference { get; set; }
    public DateTime CreatedAt { get; set; }

    public virtual Person Person { get; set; } = null!;
}

