﻿namespace SharedKernel.Domain.Entities.Common;

public class Person
{
    public int Id { get; set; }
    public int DocumentTypeId { get; set; }
    public string DocumentNumber { get; set; } = null!;
    public string Names { get; set; } = null!;
    public string FirstLastName { get; set; } = null!;
    public string SecondLastName { get; set; } = null!;
    public string? Email { get; set; }
    public DateTime BirthDate { get; set; }
    public bool Status { get; set; }

    public virtual List<PersonAddress> PersonAddresses { get; set; } = null!;
    public virtual List<PersonPhone> PersonPhones { get; set; } = null!;
}

