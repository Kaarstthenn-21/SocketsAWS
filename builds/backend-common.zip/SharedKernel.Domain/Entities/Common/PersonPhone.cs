﻿
using SharedKernel.Domain.Enums;

namespace SharedKernel.Domain.Entities.Common;
    
public class PersonPhone
{
    public int Id { get; set; }
    public int PersonId { get; set; }
    public PhoneType Type { get; set; }
    public string Number { get; set; } = null!;
    public DateTime CreatedAt { get; set; }

    public virtual Person Person { get; set; } = null!;
}

