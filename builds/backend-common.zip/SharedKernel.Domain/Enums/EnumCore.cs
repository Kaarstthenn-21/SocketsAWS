﻿namespace SharedKernel.Domain.Enums;

public enum PhoneType
{
    Celular = 1,
    Fijo = 2
}
