﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedKernel.Application.Core.Results;

public class ErrorModel
{
    public string Code { get; set; } = null!;
    public string Message { get; set; } = null!;
}

public class ResponseModel<T> //: ResponseModel
{
    public T? Data { get; set; }
    public ErrorModel[]? Errors { get; set; }

    public ResponseModel()
    {
    }

    public ResponseModel(T data)
    {
        Data = data;
    }

    public ResponseModel(ErrorModel[] errors)
    {
        Errors = errors;
    }
}
