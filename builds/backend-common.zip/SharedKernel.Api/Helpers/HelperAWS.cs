﻿using Amazon.ApiGatewayManagementApi.Model;
using Amazon.ApiGatewayManagementApi;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace SharedKernel.Api.Helpers;

public static class HelperAWS
{
    public async static void sendWSMessage(string domainName, string connectionId, object message)
    {
        var client = new AmazonApiGatewayManagementApiClient(new AmazonApiGatewayManagementApiConfig { ServiceURL = domainName });

        await client.PostToConnectionAsync(new PostToConnectionRequest
        {
            ConnectionId = connectionId,
            //Data = SerializeToStream(message)
        });
    }

    //public static MemoryStream SerializeToStream(object o)
    //{
    //    MemoryStream stream = new MemoryStream();
    //    IFormatter formatter = new BinaryFormatter();
    //    formatter.Serialize(stream, o);
    //    return stream;
    //}
}
