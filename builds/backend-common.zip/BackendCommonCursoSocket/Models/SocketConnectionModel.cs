﻿namespace BackendCommonCursoSocket.Models;

public class SocketConnectionModel
{
    public string Id { get; set; } = null!;
    public string DomainName { get; set; } = null!;
    public string Stage { get; set; } = null!;
}

