﻿namespace BackendCommonCursoSocket.Models;
    
public class PersonModel
{
    public int Id { get; set; }
    public int DocumentTypeId { get; set; }
    public string DocumentNumber { get; set; } = null!;
    public string Names { get; set; } = null!;
    public string FirstLastName { get; set; } = null!;
    public string SecondLastName { get; set; } = null!;
    public string? Email { get; set; }
    public DateTime BirthDate { get; set; }

    public List<PersonAddressModel> Addresses { get; set; } = null!;
}

public class PersonAddressModel
{
    public string Address { get; set; } = null!;
    public string? Reference { get; set; }
}