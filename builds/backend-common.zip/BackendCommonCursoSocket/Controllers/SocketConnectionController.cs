using BackendCommonCursoSocket.Application.Commands;
using BackendCommonCursoSocket.Domain.Repositories;
using BackendCommonCursoSocket.Models;
using Microsoft.AspNetCore.Mvc;
using SharedKernel.Application.Core.Results;

namespace BackendCommonCursoSocket.Controllers
{
    [ApiController]
    [Route("common/[controller]")]
    public class SocketConnectionController : ControllerBase
    {
        private readonly ILogger<SocketConnectionController> _logger;
        private readonly ISocketConnectionRepository _socketConnectionRepository;

        public SocketConnectionController(ILogger<SocketConnectionController> logger,
            ISocketConnectionRepository socketConnectionRepository)
        {
            _logger = logger;
            _socketConnectionRepository = socketConnectionRepository;
        }

        [HttpGet]
        public async Task<ResponseModel<IEnumerable<SocketConnectionModel>>> List()
        {
            var list = await _socketConnectionRepository.List();

            return new(list.Select(x => new SocketConnectionModel
            {
                Id = x.Id,
                DomainName = x.DomainName,
                Stage = x.Stage
            }));
        }

        [HttpPost]
        public async Task<ResponseModel<object>> Create(SocketConnectionCreateCommand obj)
        {
            await _socketConnectionRepository.Create(new SharedKernel.Domain.Entities.SocketConnection
            {
                Id = Guid.NewGuid().ToString(),
                DomainName = obj.DomainName,
                Stage = obj.Stage
            });

            return new();
        }

        [HttpGet("{id}")]
        public async Task<ResponseModel<SocketConnectionModel>> Obtener(string id)
        {
            var result = await _socketConnectionRepository.Get(id);

            //if (result is null) new();

            return new(new SocketConnectionModel
            {
                Id = result.Id,
                DomainName = result.DomainName,
                Stage = result.Stage
            });
        }

        [HttpDelete("{id}")]
        public async Task<ResponseModel<object>> Eliminar(string id)
        {
            var result = await _socketConnectionRepository.Get(id);

            if (result is not null)
            {
                await _socketConnectionRepository.Delete(result);
            }

            return new();

        }
    }
}