using BackendCommonCursoSocket.Application.Commands;
using BackendCommonCursoSocket.Domain.Repositories.Common;
using BackendCommonCursoSocket.Models;
using Microsoft.AspNetCore.Mvc;
using SharedKernel.Application.Core.Results;

namespace BackendCommonCursoSocket.Controllers
{
    [ApiController]
    [Route("common/[controller]")]
    public class PersonController : ControllerBase
    {
        private readonly ILogger<PersonController> _logger;
        private readonly IPersonRepository _personRepository;

        public PersonController(ILogger<PersonController> logger,
            IPersonRepository personRepository)
        {
            _logger = logger;
            _personRepository = personRepository;
        }

        [HttpGet]
        public async Task<ResponseModel<IEnumerable<PersonModel>>> List()
        {
            var list = await _personRepository.List();

            return new(list.Select(x => new PersonModel
            {
                Id = x.Id,
                DocumentTypeId = x.DocumentTypeId,
                DocumentNumber = x.DocumentNumber,
                Names = x.Names,
                FirstLastName = x.FirstLastName,
                SecondLastName = x.SecondLastName,
                Email = x.Email,
                BirthDate = x.BirthDate
            }));
        }

        [HttpGet("{id}")]
        public async Task<ResponseModel<PersonModel>> Get(int id)
        {
            var result = await _personRepository.Get(id);

            return new(new PersonModel
            {
                Id = result.Id,
                DocumentTypeId = result.DocumentTypeId,
                DocumentNumber = result.DocumentNumber,
                Names = result.Names,
                FirstLastName = result.FirstLastName,
                SecondLastName = result.SecondLastName,
                Email = result.Email,
                BirthDate = result.BirthDate,
                Addresses = result.PersonAddresses.Select(x => new PersonAddressModel
                {
                    Address = x.Address,
                    Reference = x.Reference
                }).ToList()
            });
        }

        [HttpPost]
        public async Task<ResponseModel<object>> Create(PersonCreateCommand obj)
        {
            await _personRepository.Create(new SharedKernel.Domain.Entities.Common.Person
            {
                DocumentTypeId = obj.DocumentTypeId,
                DocumentNumber = obj.DocumentNumber,
                Names = obj.Names,
                FirstLastName = obj.FirstLastName,
                SecondLastName = obj.SecondLastName,
                Email = obj.Email,
                BirthDate = obj.BirthDate,
                Status = true
            });

            return new();
        }

        [HttpPost("address/{personId}")]
        public async Task<ResponseModel<object>> CreateAddreass(int personId, PersonAddressCreateCommand obj)
        {
            await _personRepository.CreateAddress(new SharedKernel.Domain.Entities.Common.PersonAddress
            {
                PersonId = personId,
                Address = obj.Address,
                Reference = obj.Reference,
                CreatedAt = DateTime.Now
            });

            return new();
        }
    }
}