﻿using SharedKernel.Domain.Entities;

namespace BackendCommonCursoSocket.Domain.Repositories;
    
public interface ISocketConnectionRepository
{
    Task<IEnumerable<SocketConnection>> List();
    Task<SocketConnection?> Get(string id);
    Task Create(SocketConnection socketConnection);
    Task Update(string id, string stage);
    Task Delete(SocketConnection socketConnection);
}