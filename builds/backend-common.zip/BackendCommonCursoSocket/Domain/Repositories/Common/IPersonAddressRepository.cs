﻿using SharedKernel.Domain.Entities.Common;

namespace BackendCommonCursoSocket.Domain.Repositories.Common;
    
public interface IPersonAddressRepository
{
    Task<IEnumerable<PersonAddress>> List();
    Task<PersonAddress?> Get(int id);
    Task Create(PersonAddress person);
    Task Update(PersonAddress person);
    Task Delete(int id);
}
