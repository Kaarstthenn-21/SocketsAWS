﻿using SharedKernel.Domain.Entities.Common;

namespace BackendCommonCursoSocket.Domain.Repositories.Common;

public interface IPersonPhoneRepository
{
    Task<IEnumerable<PersonPhone>> List();
    Task<PersonPhone?> Get(int id);
    Task Create(PersonPhone person);
    Task Update(PersonPhone person);
    Task Delete(int id);
}

