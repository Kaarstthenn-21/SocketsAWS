﻿using SharedKernel.Domain.Entities.Common;

namespace BackendCommonCursoSocket.Domain.Repositories.Common;
    
public interface IPersonRepository
{
    Task<IEnumerable<Person>> List();
    Task<Person?> Get(int id);
    Task Create(Person person);
    Task Update(Person person);
    Task Delete(int id);

    Task CreateAddress(PersonAddress personAddress);

    Task CreatePhone(PersonPhone personPhone);
}
