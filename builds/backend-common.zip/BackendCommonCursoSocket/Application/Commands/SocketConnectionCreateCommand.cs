﻿namespace BackendCommonCursoSocket.Application.Commands;
    
public record SocketConnectionCreateCommand(
        string DomainName,
        string Stage
    );

