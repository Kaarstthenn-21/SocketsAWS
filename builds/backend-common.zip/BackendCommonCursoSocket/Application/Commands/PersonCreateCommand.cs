﻿namespace BackendCommonCursoSocket.Application.Commands;

public record PersonCreateCommand(
        int DocumentTypeId,
        string DocumentNumber,
        string Names,
        string FirstLastName,
        string SecondLastName,
        string? Email,
        DateTime BirthDate
    );


public record PersonAddressCreateCommand(
        string Address,
        string? Reference
    );