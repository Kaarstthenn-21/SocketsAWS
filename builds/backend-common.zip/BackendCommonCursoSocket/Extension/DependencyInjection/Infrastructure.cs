﻿using BackendCommonCursoSocket.Domain.Repositories;
using BackendCommonCursoSocket.Domain.Repositories.Common;
using BackendCommonCursoSocket.Infrastructure;
using BackendCommonCursoSocket.Infrastructure.Common;
using Microsoft.EntityFrameworkCore;
using SharedKernel.Infrastructure.Context;

namespace BackendCommonCursoSocket.Extension.DependencyInjection;
    
internal static class Infrastructure
{

    internal static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddDbContext<SharedKernelDbContext>((provider, options) =>
        {
            var cadena = "";
            var env = Environment.GetEnvironmentVariable("Env");

            if (env is null)
            {
                cadena = configuration.GetConnectionString("DefaultConnection");
            }
            else
            {
                cadena = $"server={Environment.GetEnvironmentVariable("ServerDB")};database={Environment.GetEnvironmentVariable("DatabaseName")};user={Environment.GetEnvironmentVariable("UserDB")};password={Environment.GetEnvironmentVariable("PasswordDB")}";
            }

            options.UseMySQL(cadena);
        });

        services.AddScoped<ISocketConnectionRepository, SocketConnectionRepository>();
        services.AddScoped<IPersonRepository, PersonRepository>();

        return services;
    }

}

