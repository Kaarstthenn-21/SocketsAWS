﻿using BackendCommonCursoSocket.Domain.Repositories.Common;
using Microsoft.EntityFrameworkCore;
using SharedKernel.Domain.Entities.Common;
using SharedKernel.Infrastructure.Context;

namespace BackendCommonCursoSocket.Infrastructure.Common;

public class PersonRepository : IPersonRepository
{
    private readonly SharedKernelDbContext _db;

    public PersonRepository(SharedKernelDbContext db)
    {
        _db = db;
    }

    public async Task<IEnumerable<Person>> List()
    {
        var list = await _db.People.Where(x => x.Status == true).ToListAsync();

        return list;
    }

    public async Task<Person?> Get(int id)
    {
        var result = await _db.People.Include(x => x.PersonAddresses).Where(x => x.Id == id).FirstOrDefaultAsync();
        
        return result;
    }

    public async Task Create(Person person)
    {
        await _db.People.AddAsync(person);

        await _db.SaveChangesAsync();
    }

    public async Task Update(Person person)
    {
        _db.People.Update(person);

        await _db.SaveChangesAsync();
    }

    public async Task Delete(int id)
    {
        await _db.People.Where(x => x.Id == id).ExecuteUpdateAsync(x => x.SetProperty(c => c.Status, c => false));
    }

    public async Task CreateAddress(PersonAddress personAddress)
    {
        await _db.PersonAddresses.AddAsync(personAddress);

        await _db.SaveChangesAsync();
    }

    public async Task CreatePhone(PersonPhone personPhone)
    {
        await _db.PersonPhones.AddAsync(personPhone);

        await _db.SaveChangesAsync();
    }
}

