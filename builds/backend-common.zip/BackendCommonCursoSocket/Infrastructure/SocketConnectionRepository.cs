﻿using BackendCommonCursoSocket.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using SharedKernel.Domain.Entities;
using SharedKernel.Infrastructure.Context;

namespace BackendCommonCursoSocket.Infrastructure;

public class SocketConnectionRepository : ISocketConnectionRepository
{
    private readonly SharedKernelDbContext _db;

    public SocketConnectionRepository(SharedKernelDbContext db)
    {
        _db = db;
    }

    public async Task<IEnumerable<SocketConnection>> List()
    {
        var list = await _db.SocketConnections.ToListAsync();

        return list;
    }

    public async Task<SocketConnection?> Get(string id)
    {
        var result = await _db.SocketConnections.FindAsync(id);

        return result;
    }

    public async Task Create(SocketConnection socketConnection)
    {
        await _db.SocketConnections.AddAsync(socketConnection);

        await _db.SaveChangesAsync();
    }

    public async Task Update(string id, string stage)
    {
        await _db.SocketConnections.Where(x => x.Id == id).ExecuteUpdateAsync(x => x.SetProperty(c => c.Stage, stage));
    }

    public async Task Delete(SocketConnection socketConnection)
    {
        _db.SocketConnections.Remove(socketConnection);

        await _db.SaveChangesAsync();
    }
}

