﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SharedKernel.Infrastructure.Context;

CreateHostBuilder(args).Build().Run();
static IHostBuilder CreateHostBuilder(string[] args) => Host.CreateDefaultBuilder(args)
    .ConfigureServices((host, services) =>
    {
        services.AddDbContext<SharedKernelDbContext>(options =>
        {
            options.UseMySQL("server=LB-CARLOSOCAS-ff823c9261e3daaa.elb.us-east-1.amazonaws.com;database=CARLOSOCAS0001CURSO01;user=root;password=tMZVVm1DmWH02KU", x => x.MigrationsAssembly("Data.Migrations"));
        });
    });