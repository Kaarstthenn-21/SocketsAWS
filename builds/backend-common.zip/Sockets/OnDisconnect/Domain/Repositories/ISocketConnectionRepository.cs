﻿using SharedKernel.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnDisconnect.Domain.Repositories;

public interface ISocketConnectionRepository
{
    Task<IEnumerable<SocketConnection>> List();
    Task<SocketConnection?> Get(string id);
    Task Delete(SocketConnection socketConnection);
}
