﻿using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.Core;
using Microsoft.Extensions.DependencyInjection;
using SharedKernel.Infrastructure.Context;
using Microsoft.EntityFrameworkCore;
using OnDisconnect.Domain.Repositories;
using OnDisconnect.Infrastructure;

[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

// dotnet publish /p:GenerateRuntimeConfigurationFiles=true

namespace OnDisconnect
{
    public class Function
    {
        readonly ServiceProvider _serviceProvider;

        public Function()
        {
            var serviceCollection = new ServiceCollection();

            serviceCollection.AddDbContext<SharedKernelDbContext>((provider, options) =>
            {
                var cadena = "";
                cadena = $"server={Environment.GetEnvironmentVariable("ServerDB")};database={Environment.GetEnvironmentVariable("DatabaseName")};user={Environment.GetEnvironmentVariable("UserDB")};password={Environment.GetEnvironmentVariable("PasswordDB")}";

                options.UseMySQL(cadena);
            });

            serviceCollection.AddScoped<ISocketConnectionRepository, SocketConnectionRepository>();

            _serviceProvider = serviceCollection.BuildServiceProvider();
        }

        public async Task<APIGatewayProxyResponse> Handler(APIGatewayProxyRequest request, ILambdaContext context)
        {   
            try
            {
                context.Logger.LogLine("************** ConnectionId: " + request.RequestContext.ConnectionId);
                context.Logger.LogLine("************** DomainName: " + request.RequestContext.DomainName);
                context.Logger.LogLine("************** Stage: " + request.RequestContext.Stage);

                using (var scope = _serviceProvider.CreateScope())
                {
                    var socketConnectionRepository = scope.ServiceProvider.GetRequiredService<ISocketConnectionRepository>();

                    var connection = await socketConnectionRepository.Get(request.RequestContext.ConnectionId);

                    if (connection is not null)
                    {
                        await socketConnectionRepository.Delete(connection);
                    }
                }

                return new APIGatewayProxyResponse
                {
                    StatusCode = 200,
                    Body = "Disconnected"
                };
            }
            catch (Exception e)
            {
                context.Logger.LogLine("Error connecting: " + e.Message);
                context.Logger.LogLine(e.StackTrace);

                return new APIGatewayProxyResponse
                {
                    StatusCode = 500,
                    Body = $"Failed to connect: {e.Message}"
                };
            }
        }
    }
}