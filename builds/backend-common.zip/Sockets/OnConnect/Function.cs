﻿using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.Core;
using Microsoft.Extensions.DependencyInjection;
using OnConnect.Domain.Repositories;
using OnConnect.Infrastructure;
using SharedKernel.Infrastructure.Context;
using Microsoft.EntityFrameworkCore;

[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

// dotnet publish /p:GenerateRuntimeConfigurationFiles=true

namespace OnConnect
{
    public class Function
    {
        readonly ServiceProvider _serviceProvider;

        public Function()
        {
            var serviceCollection = new ServiceCollection();

            serviceCollection.AddDbContext<SharedKernelDbContext>((provider, options) =>
            {
                var cadena = "";
                cadena = $"server={Environment.GetEnvironmentVariable("ServerDB")};database={Environment.GetEnvironmentVariable("DatabaseName")};user={Environment.GetEnvironmentVariable("UserDB")};password={Environment.GetEnvironmentVariable("PasswordDB")}";
                
                options.UseMySQL(cadena);
            });

            serviceCollection.AddScoped<ISocketConnectionRepository, SocketConnectionRepository>();

            _serviceProvider = serviceCollection.BuildServiceProvider();
        }

        public async Task<APIGatewayProxyResponse> Handler(APIGatewayProxyRequest request, ILambdaContext context)
        {
            try
            {
                context.Logger.LogLine("************** ConnectionId: " + request.RequestContext.ConnectionId);
                context.Logger.LogLine("************** DomainName: " + request.RequestContext.DomainName);
                context.Logger.LogLine("************** Stage: " + request.RequestContext.Stage);

                using (var scope = _serviceProvider.CreateScope())
                {
                    var socketConnectionRepository = scope.ServiceProvider.GetRequiredService<ISocketConnectionRepository>();
                    
                    await socketConnectionRepository.Create(new SharedKernel.Domain.Entities.SocketConnection
                    {
                        Id = request.RequestContext.ConnectionId,
                        DomainName = request.RequestContext.DomainName,
                        Stage = request.RequestContext.Stage,
                        CreationDate = DateTime.Now,
                        CreatedBy = "OnConnect"
                    });
                }

                return new APIGatewayProxyResponse
                {
                    StatusCode = 200,
                    Body = "Connected"
                };
            }
            catch (Exception e)
            {
                context.Logger.LogLine("Error: " + e.Message);
                context.Logger.LogLine(e.StackTrace);

                return new APIGatewayProxyResponse
                {
                    StatusCode = 500,
                    Body = $"Failed: {e.Message}"
                };
            }
        }
    }
}