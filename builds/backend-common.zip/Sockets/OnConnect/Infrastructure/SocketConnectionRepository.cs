﻿using Microsoft.EntityFrameworkCore;
using OnConnect.Domain.Repositories;
using SharedKernel.Domain.Entities;
using SharedKernel.Infrastructure.Context;

namespace OnConnect.Infrastructure;

public class SocketConnectionRepository : ISocketConnectionRepository
{
    private readonly SharedKernelDbContext _db;

    public SocketConnectionRepository(SharedKernelDbContext db)
    {
        _db = db;
    }

    public async Task<IEnumerable<SocketConnection>> List()
    {
        var list = await _db.SocketConnections.ToListAsync();

        return list;
    }

    public async Task Create(SocketConnection socketConnection)
    {
        await _db.SocketConnections.AddAsync(socketConnection);

        await _db.SaveChangesAsync();
    }
}