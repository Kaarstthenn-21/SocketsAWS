﻿using SharedKernel.Domain.Entities;

namespace OnConnect.Domain.Repositories;

public interface ISocketConnectionRepository
{
    Task<IEnumerable<SocketConnection>> List(); 
    Task Create(SocketConnection socketConnection);
}