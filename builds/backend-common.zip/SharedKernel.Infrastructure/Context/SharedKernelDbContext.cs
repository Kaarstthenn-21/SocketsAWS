﻿using Microsoft.EntityFrameworkCore;
using SharedKernel.Domain.Entities;
using SharedKernel.Domain.Entities.Common;
using SharedKernel.Infrastructure.Configurations;
using SharedKernel.Infrastructure.Configurations.Common;

namespace SharedKernel.Infrastructure.Context;

public class SharedKernelDbContext : DbContext
{
    public DbSet<SocketConnection> SocketConnections { get; set; }
    public DbSet<Person> People { get; set; }
    public DbSet<PersonAddress> PersonAddresses { get; set; }
    public DbSet<PersonPhone> PersonPhones { get; set; }

    public SharedKernelDbContext(DbContextOptions options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.ApplyConfiguration(new SocketConnectionEntityTypeConfiguration());
        modelBuilder.ApplyConfiguration(new PersonAddressEntityTypeConfiguration());
        modelBuilder.ApplyConfiguration(new PersonEntityTypeConfiguration());
        modelBuilder.ApplyConfiguration(new PersonPhoneEntityTypeConfiguration());

    }

}

