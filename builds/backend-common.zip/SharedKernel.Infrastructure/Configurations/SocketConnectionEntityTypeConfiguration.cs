﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SharedKernel.Domain.Entities;

namespace SharedKernel.Infrastructure.Configurations;

public class SocketConnectionEntityTypeConfiguration : IEntityTypeConfiguration<SocketConnection>
{
    public void Configure(EntityTypeBuilder<SocketConnection> builder)
    {
        builder.ToTable("socketconnection");

        builder.Property(x => x.Id)
            .HasMaxLength(50)
            .IsUnicode(false)
            .IsRequired();

        builder.Property(x => x.DomainName)
            .HasMaxLength(100)
            .IsUnicode(false)
            .IsRequired();

        builder.Property(x => x.Stage)
            .HasMaxLength(100)
            .IsUnicode(false)
            .IsRequired();

        builder.Property(x => x.CreatedBy)
            .HasMaxLength(50)
            .IsUnicode(false)
            .IsRequired(false);

    }
}
