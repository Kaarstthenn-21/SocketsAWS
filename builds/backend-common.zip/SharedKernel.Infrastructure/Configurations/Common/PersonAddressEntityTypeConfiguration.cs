﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SharedKernel.Domain.Entities.Common;

namespace SharedKernel.Infrastructure.Configurations.Common;

public class PersonAddressEntityTypeConfiguration : IEntityTypeConfiguration<PersonAddress>
{
    public void Configure(EntityTypeBuilder<PersonAddress> builder)
    {
        builder.ToTable("personaddress");

        builder.Property(x => x.PersonId)
            .IsRequired();

        builder.Property(x => x.Address)
            .IsRequired()
            .IsUnicode(false)
            .HasMaxLength(100);

        builder.Property(x => x.Reference)
            .IsRequired(false)
            .IsUnicode(false)
            .HasMaxLength(100);

        builder.Property(x => x.CreatedAt)
            .IsRequired();

        builder.HasOne(pp => pp.Person)
            .WithMany(p => p.PersonAddresses)
            .HasForeignKey(pp => pp.PersonId);
    }
}
