﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SharedKernel.Domain.Entities.Common;

namespace SharedKernel.Infrastructure.Configurations.Common;

public class PersonPhoneEntityTypeConfiguration : IEntityTypeConfiguration<PersonPhone>
{
    public void Configure(EntityTypeBuilder<PersonPhone> builder)
    {
        builder.ToTable("personphone");

        builder.Property(x => x.PersonId)
            .IsRequired();

        builder.Property(x => x.Type)
            .IsRequired();

        builder.Property(x => x.Number)
            .IsRequired()
            .IsUnicode(false)
            .HasMaxLength(20);

        builder.Property(x => x.CreatedAt)
            .IsRequired();

        builder.HasOne(pp => pp.Person)
            .WithMany(p => p.PersonPhones)
            .HasForeignKey(pp => pp.PersonId);
    }
}

