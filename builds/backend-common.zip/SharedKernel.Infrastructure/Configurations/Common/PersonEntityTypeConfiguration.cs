﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SharedKernel.Domain.Entities;
using SharedKernel.Domain.Entities.Common;

namespace SharedKernel.Infrastructure.Configurations.Common;

public class PersonEntityTypeConfiguration : IEntityTypeConfiguration<Person>
{
    public void Configure(EntityTypeBuilder<Person> builder)
    {
        builder.ToTable("person");

        builder.Property(x => x.DocumentTypeId)
            .IsRequired();

        builder.Property(x => x.DocumentNumber)
            .IsRequired()
            .IsUnicode(false)
            .HasMaxLength(20);

        builder.Property(x => x.Names)
            .IsRequired()
            .IsUnicode(false)
            .HasMaxLength(50);

        builder.Property(x => x.FirstLastName)
            .IsRequired()
            .IsUnicode(false)
            .HasMaxLength(50);

        builder.Property(x => x.SecondLastName)
            .IsRequired()
            .IsUnicode(false)
            .HasMaxLength(50);

        builder.Property(x => x.Email)
            .IsRequired(false)
            .IsUnicode(false)
            .HasMaxLength(250);

        builder.Property(x => x.Email)
            .IsRequired(false);
    }
}
